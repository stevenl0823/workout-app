'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { useToken } from '@/lib/auth';
import { inp, btn } from '@/lib/ui';
const blank = { exercise_id: '', sets: 3, reps: 10, weight_kg: 0, rpe: 6 };
export default function LogForm({ id }: { id?: string }) {
  useToken(); const r = useRouter(); const [lib, setLib] = useState<any[]>([]); const [rows, setRows] = useState<any[]>([{ ...blank }]); const [err, setErr] = useState('');
  const [m, setM] = useState({ status: 'completed', body_feeling: '', notes: '' });
  useEffect(() => { supabase.from('exercises').select('id,name').order('name').then(({ data }) => setLib(data ?? [])); }, []);
  useEffect(() => { if (!id) return; supabase.from('workout_logs').select('status,body_feeling,notes,workout_log_exercises(exercise_id,sets,reps,weight_kg,rpe)').eq('id', id).single().then(({ data }) => { if (!data) return; setM({ status: data.status, body_feeling: data.body_feeling ?? '', notes: data.notes ?? '' }); setRows(data.workout_log_exercises.map((x: any) => ({ ...x, weight_kg: x.weight_kg ?? 0 }))); }); }, [id]);
  const upd = (i: number, k: string, v: any) => setRows(rows.map((x, j) => (j === i ? { ...x, [k]: v } : x)));
  async function save(e: React.FormEvent) {
    e.preventDefault(); const { data: { user } } = await supabase.auth.getUser(); if (!user) return;
    let logId = id;
    if (id) { const { error } = await supabase.from('workout_logs').update(m).eq('id', id).eq('user_id', user.id); if (error) return setErr(error.message); await supabase.from('workout_log_exercises').delete().eq('log_id', id); }
    else { const { data: log, error } = await supabase.from('workout_logs').insert({ ...m, user_id: user.id }).select('id').single(); if (error) return setErr(error.message); logId = log.id; }
    const { error: e2 } = await supabase.from('workout_log_exercises').insert(rows.filter(x => x.exercise_id).map(x => ({ ...x, weight_kg: x.weight_kg || null, log_id: logId })));
    e2 ? setErr(e2.message) : r.push('/history');
  }
  return (<form onSubmit={save} className="space-y-3">
    <h1 className="text-2xl font-bold">{id ? 'Edit workout' : 'Log a workout'}</h1>
    {rows.map((x, i) => (<div key={i} className="grid grid-cols-4 gap-2 rounded border bg-white p-3">
      <select className={inp + ' col-span-4'} required value={x.exercise_id} onChange={e => upd(i, 'exercise_id', e.target.value)}><option value="">Choose exercise</option>{lib.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}</select>
      {[['sets', 'Sets'], ['reps', 'Reps'], ['weight_kg', 'kg'], ['rpe', 'RPE 1-10']].map(([k, l]) => <label key={k} className="text-xs">{l}<input className={inp} type="number" min={k === 'rpe' ? 1 : 0} max={k === 'rpe' ? 10 : undefined} value={x[k]} onChange={e => upd(i, k, +e.target.value)} /></label>)}
    </div>))}
    <button type="button" className="text-sm text-blue-700 underline" onClick={() => setRows([...rows, { ...blank }])}>Add exercise</button>
    <select className={inp} value={m.status} onChange={e => setM({ ...m, status: e.target.value })}><option value="completed">Completed</option><option value="partial">Partly completed</option><option value="skipped">Skipped</option></select>
    <input className={inp} placeholder="How does your body feel now?" value={m.body_feeling} onChange={e => setM({ ...m, body_feeling: e.target.value })} />
    <textarea className={inp} placeholder="Notes (optional)" value={m.notes} onChange={e => setM({ ...m, notes: e.target.value })} />
    {err && <p className="text-sm text-red-700" role="alert">{err}</p>}<button className={btn}>Save workout</button>
  </form>);
}
