# FitAdapt (MVP core)

Stack: Next.js + TypeScript, Tailwind, Supabase (Postgres, Auth, RLS), Recharts.

## Included
- `supabase/migrations/0001_schema.sql`: all 12 tables, role signup trigger, `can_view()` consent check, RLS on every table, audit triggers, `decide_recommendation()` RPC, seed exercises.
- `src/lib/recommend.ts`: rule-based, explainable engine with a config object and a pure signature, ready for ML later.

## Security model
- Private by default: no grant, no access. Friends and therapists need an accepted connection plus an un-revoked `sharing_permissions` row.
- Revoking sets `revoked_at`; the next query is denied. Grants are never deleted, so the audit trail stays intact.
- Therapists can only insert `pt_recommendations`; no policy lets them write plans. Users accept/reject through `decide_recommendation()`.
- `readiness` data is visible only to verified therapists (`pt_verified` is admin-set).

## Run
`cp .env.example .env.local` (add the anon key), `supabase start && supabase db reset`, `npm install`, `npm run dev`.

## Built
Sign-up/sign-in with role, onboarding, daily check-in, explainable recommendation (server route, runs under the user's JWT), home dashboard, workout logger with editing, history with calendar, search, edit and delete, connections (invite, accept, remove), per-person privacy switches, a progress page with Recharts, a shared-data view for friends and therapists, and therapist suggestions that users accept or reject.

## Test the access rules
`psql postgresql://postgres:postgres@127.0.0.1:54322/postgres -f supabase/tests/access.sql` prints PASS/FAIL per rule (expected denials show as ERROR lines).

## Verify a therapist
Edit the email in `supabase/admin/verify_therapist.sql` and run it as the database owner.

## Not built yet
`summary`/`progress` aggregate sharing views (only profile summary, logs and check-ins are shareable today), plan customization UI beyond regenerate, and AI/ML recommendations. Not yet type-checked, and the SQL tests have not been run.
