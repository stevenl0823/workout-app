'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase';
import { useToken } from '@/lib/auth';
export default function Home() {
  useToken(); const [d, setD] = useState<any>(null);
  useEffect(() => { (async () => {
    const { data: { user } } = await supabase.auth.getUser(); if (!user) return;
    const today = new Date().toISOString().slice(0, 10), week = new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10);
    const [p, l] = await Promise.all([
      supabase.from('workout_plans').select('training_type,intensity,est_minutes,explanation,workout_plan_exercises(sets,reps,exercises(name))').eq('user_id', user.id).eq('plan_date', today).order('created_at', { ascending: false }).limit(1),
      supabase.from('workout_logs').select('id,logged_on,status').eq('user_id', user.id).order('logged_on', { ascending: false }).limit(20)]);
    setD({ plan: p.data?.[0], recent: (l.data ?? []).slice(0, 3), week: (l.data ?? []).filter((x: any) => x.logged_on >= week && x.status !== 'skipped').length });
  })(); }, []);
  if (!d) return <p>Loading…</p>;
  const lk = 'text-blue-700 underline';
  return (<div className="space-y-4"><h1 className="text-2xl font-bold">Today</h1>
    <section className="rounded border bg-white p-3">{d.plan ? (<><b>{d.plan.training_type} · {d.plan.intensity}{d.plan.est_minutes ? ` · about ${d.plan.est_minutes} min` : ''}</b>
      {d.plan.workout_plan_exercises.map((x: any, i: number) => <p key={i} className="text-sm">{x.exercises.name}: {x.sets} × {x.reps}</p>)}<p className="mt-2 text-sm text-slate-600">{d.plan.explanation}</p></>)
      : <p>No workout yet today. <Link className={lk} href="/check-in">Do your check-in</Link> to get one.</p>}</section>
    <p className="text-sm">{d.week} workout{d.week === 1 ? '' : 's'} in the last 7 days. <Link className={lk} href="/analytics">See progress</Link></p>
    <section><h2 className="font-semibold">Recent activity</h2>{!d.recent.length && <p className="text-sm text-slate-600">Nothing logged yet.</p>}
      {d.recent.map((x: any) => <p key={x.id} className="text-sm">{x.logged_on} · {x.status} · <Link className={lk} href={`/log/${x.id}`}>Edit</Link></p>)}</section>
  </div>);
}
